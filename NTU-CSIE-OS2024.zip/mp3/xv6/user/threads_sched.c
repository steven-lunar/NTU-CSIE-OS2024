#include "kernel/types.h"
#include "user/user.h"
#include "user/list.h"
#include "user/threads.h"
#include "user/threads_sched.h"

#define NULL 0

/* default scheduling algorithm */
struct threads_sched_result schedule_default(struct threads_sched_args args)
{
    struct thread *thread_with_smallest_id = NULL;
    struct thread *th = NULL;
    list_for_each_entry(th, args.run_queue, thread_list) {
        if (thread_with_smallest_id == NULL || th->ID < thread_with_smallest_id->ID)
            thread_with_smallest_id = th;
    }

    struct threads_sched_result r;
    if (thread_with_smallest_id != NULL) {
        r.scheduled_thread_list_member = &thread_with_smallest_id->thread_list;
        r.allocated_time = thread_with_smallest_id->remaining_time;
    } else {
        r.scheduled_thread_list_member = args.run_queue;
        r.allocated_time = 1;
    }

    return r;
}

/* MP3 Part 1 - Non-Real-Time Scheduling */
/* Weighted-Round-Robin Scheduling */
struct threads_sched_result schedule_wrr(struct threads_sched_args args)
{
    struct threads_sched_result r;
    // TODO: implement the weighted round-robin scheduling algorithm
    struct thread *nearest_thread = NULL;
    struct thread *th = NULL;
    if (!list_empty(args.run_queue)){
        list_for_each_entry(th, args.run_queue, thread_list){
            nearest_thread = th;
            break;
        }
        r.scheduled_thread_list_member = &nearest_thread->thread_list;
        if ((nearest_thread->weight * args.time_quantum) >= nearest_thread->remaining_time){
            r.allocated_time = nearest_thread->remaining_time;
        }
        else{
            r.allocated_time = (nearest_thread->weight * args.time_quantum);
        }
    }
    else{
        struct release_queue_entry* rqe = NULL;
        struct release_queue_entry* nearest_rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (nearest_rqe == NULL || rqe->release_time <= nearest_rqe->release_time)
                nearest_rqe = rqe;
        }
        r.scheduled_thread_list_member = args.run_queue;
        r.allocated_time = (nearest_rqe->release_time - args.current_time);
    }
    return r;
}

/* Shortest-Job-First Scheduling */
struct threads_sched_result schedule_sjf(struct threads_sched_args args)
{
    struct threads_sched_result r;
    // TODO: implement the shortest-job-first scheduling algorithm
    struct thread *shortest_thread = NULL;
    struct thread *th = NULL;
    if (!list_empty(args.run_queue)){
        list_for_each_entry(th, args.run_queue, thread_list){
            if ((shortest_thread == NULL) || (th->remaining_time < shortest_thread->remaining_time) || 
                ((th->remaining_time == shortest_thread->remaining_time) && th->ID < shortest_thread->ID)){
                shortest_thread = th;
            }
        }

        r.scheduled_thread_list_member = &shortest_thread->thread_list;
        r.allocated_time = shortest_thread->remaining_time;

        struct release_queue_entry* rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (rqe->release_time < (args.current_time + shortest_thread->remaining_time)){
                int pre_executed_time = rqe->release_time - args.current_time;
                if ((rqe->thrd->remaining_time < (shortest_thread->remaining_time - pre_executed_time))
                    || ((rqe->thrd->remaining_time == (shortest_thread->remaining_time - pre_executed_time)) && (rqe->thrd->ID < shortest_thread->ID))){
                    if (r.allocated_time > rqe->release_time - args.current_time)
                        r.allocated_time = rqe->release_time - args.current_time;
                }
            }
        }
    }
    else{
        struct release_queue_entry* rqe = NULL;
        struct release_queue_entry* nearest_rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (nearest_rqe == NULL || rqe->release_time <= nearest_rqe->release_time)
                nearest_rqe = rqe;
        }
        r.scheduled_thread_list_member = args.run_queue;
        r.allocated_time = (nearest_rqe->release_time - args.current_time);
    }
    return r;
}

/* MP3 Part 2 - Real-Time Scheduling*/
/* Least-Slack-Time Scheduling */
struct threads_sched_result schedule_lst(struct threads_sched_args args)
{
    struct threads_sched_result r;
    // TODO: implement the least-slack-time scheduling algorithm
    struct thread *LST_thread = NULL;
    struct thread *th = NULL;
    if (!list_empty(args.run_queue)){
        // to check there is thread miss the deadline already
        struct thread *missed_thread = NULL;
        list_for_each_entry(th, args.run_queue, thread_list){
            if ((th->current_deadline <= args.current_time) && th->remaining_time > 0){
                if (missed_thread == NULL || th->ID < missed_thread->ID){
                    missed_thread = th;
                }
            }
        }
        if (missed_thread != NULL){
            r.scheduled_thread_list_member = &missed_thread->thread_list;
            r.allocated_time = 0;
            return r;
        }

        int min_slack_time = 1000;
        list_for_each_entry(th, args.run_queue, thread_list){
            int slack_time = th->current_deadline - args.current_time - th->remaining_time;
            if (LST_thread == NULL || (slack_time < min_slack_time) ||
                ((slack_time == min_slack_time) && (th->ID < LST_thread->ID))){
                LST_thread = th;
                min_slack_time = slack_time;
            }
        }

        r.scheduled_thread_list_member = &LST_thread->thread_list;
        if (LST_thread->remaining_time > (LST_thread->current_deadline - args.current_time))
            r.allocated_time = (LST_thread->current_deadline - args.current_time);
        else
            r.allocated_time = LST_thread->remaining_time;
            
        struct release_queue_entry* rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (rqe->release_time < (LST_thread->remaining_time + args.current_time)){
                int pre_executed_time = rqe->release_time - args.current_time;
                int new_remaining_time_LST = LST_thread->remaining_time - pre_executed_time;
                int slack_time_run = LST_thread->current_deadline - rqe->release_time - new_remaining_time_LST;
                int slack_time_release =  rqe->thrd->current_deadline - rqe->release_time - rqe->thrd->processing_time;
                if ((slack_time_release < slack_time_run) || 
                    ((slack_time_release == slack_time_run) && (rqe->thrd->ID < LST_thread->ID))){
                    if (r.allocated_time > (rqe->release_time - args.current_time))
                        r.allocated_time = rqe->release_time - args.current_time;
                }
            }
        }
    }
    else{
        struct release_queue_entry* rqe = NULL;
        struct release_queue_entry* nearest_rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (nearest_rqe == NULL || rqe->release_time <= nearest_rqe->release_time)
                nearest_rqe = rqe;
        }
        r.scheduled_thread_list_member = args.run_queue;
        r.allocated_time = (nearest_rqe->release_time - args.current_time);
    }
    return r;
}

/* Deadline-Monotonic Scheduling */
struct threads_sched_result schedule_dm(struct threads_sched_args args)
{
    struct threads_sched_result r;
    // TODO: implement the deadline-monotonic scheduling algorithm
    struct thread *shortest_period_thread = NULL;
    struct thread *th = NULL;
    if (!list_empty(args.run_queue)){
        // to check there is thread miss the deadline already
        struct thread *missed_thread = NULL;
        list_for_each_entry(th, args.run_queue, thread_list){
            if ((th->current_deadline <= args.current_time) && th->remaining_time > 0){
                if (missed_thread == NULL || th->ID < missed_thread->ID){
                    missed_thread = th;
                }
            }
        }
        if (missed_thread != NULL){
            r.scheduled_thread_list_member = &missed_thread->thread_list;
            r.allocated_time = 0;
            return r;
        }

        list_for_each_entry(th, args.run_queue, thread_list){
            if ((shortest_period_thread == NULL) || (th->period < shortest_period_thread->period) 
                || ((th->period == shortest_period_thread->period) && (th->ID < shortest_period_thread->ID))){
                shortest_period_thread = th;
            }
        }

        r.scheduled_thread_list_member = &shortest_period_thread->thread_list;
        if (shortest_period_thread->remaining_time > (shortest_period_thread->current_deadline - args.current_time))
            r.allocated_time = (shortest_period_thread->current_deadline - args.current_time);
        else
            r.allocated_time = shortest_period_thread->remaining_time;

        struct release_queue_entry* rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (rqe->release_time < (shortest_period_thread->remaining_time + args.current_time)){
                if ((rqe->thrd->period < shortest_period_thread->period) || 
                    ((rqe->thrd->period == shortest_period_thread->period) && (rqe->thrd->ID < shortest_period_thread->ID))){
                    if (r.allocated_time > (rqe->release_time - args.current_time))
                        r.allocated_time = (rqe->release_time - args.current_time);
                }
            }
        }
    }
    else{
        struct release_queue_entry* rqe = NULL;
        struct release_queue_entry* nearest_rqe = NULL;
        list_for_each_entry(rqe, args.release_queue, thread_list){
            if (nearest_rqe == NULL || rqe->release_time <= nearest_rqe->release_time)
                nearest_rqe = rqe;
        }
        r.scheduled_thread_list_member = args.run_queue;
        r.allocated_time = (nearest_rqe->release_time - args.current_time);
    }
    return r;
}
