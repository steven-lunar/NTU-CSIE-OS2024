#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

int glo_dir_num = 0;
int glo_file_num = 0;

int occur_estimate(char* path, char key){
    int occurence = 0;
    int len = strlen(path);
    for (int i = 0; i < len; ++i){
        if (path[i] == key)
            occurence++;
    }
    
    return occurence;
};

void mp0(char* path, char key){
    char buf[128] = {0};
    strcpy(buf, path);
    int len = strlen(buf);
    struct dirent de[20];
    struct stat st;
    int fd;
    int occurence = 0;
    int dirent_idx = 0;

    occurence = occur_estimate(path, key);
    printf("%s %d\n", path, occurence);

    if ((fd = open(path, 0)) < 0){
        fprintf(2, "open failed\n");
        return;
    }
    // printf("%s with fd: %d\n", path, fd);
    if (fstat(fd, &st) < 0){
        fprintf(2, "fstat failed\n");
        return;
    }

    switch(st.type){
        case T_FILE:
            glo_file_num++;
            close(fd);
            break;
        
        case T_DIR:
            glo_dir_num++;
            while(read(fd, &de[dirent_idx], sizeof(de[dirent_idx])) == sizeof(de[dirent_idx])){
                if(de[dirent_idx].inum == 0)
                    continue;
                dirent_idx++;
            }
            close(fd);

            for (int i = 0; i < dirent_idx; ++i){
                if ((strcmp(de[i].name, ".") == 0) || (strcmp(de[i].name, "..") == 0))
                    continue;
                char newpath[64] = {0};
                strcpy(newpath, path);
                newpath[len] = '/';
                memmove(newpath + len + 1, de[i].name, DIRSIZ);
                mp0(newpath, key);
            }

            break;
    }

    return;
};



int main(int argc, char **argv){
    if (argc < 3){
        printf("Usage: mp0 [root_directory] [key]");
        exit(1);
    }

    int fd;
    char path[64] = {0};
    char key = argv[2][0];
    int dir_num = 0;
    int file_num = 0;
    struct stat st;
    strcpy(path, argv[1]);

    int pipe1_fd[2];
    int pipe2_fd[2];

    if (pipe(pipe1_fd) < 0){
        fprintf(2, "pipe failed\n");
        exit(0);
    }

    if (pipe(pipe2_fd) < 0){
        fprintf(2, "pipe failed\n");
        exit(0);
    }

    int PID = fork();
    // printf("%d\n", PID);
    if (PID == 0){
        if ((fd = open(path, 0)) <= 0){
            printf("%s [error opening dir]\n", path);
            close(pipe1_fd[0]);
            close(pipe2_fd[0]);
            write(pipe1_fd[1], &glo_dir_num, sizeof(glo_dir_num));
            write(pipe2_fd[1], &glo_file_num, sizeof(glo_file_num));
            exit(0);
        }
        else{
            if (fstat(fd, &st) < 0){
                fprintf(2, "fstat failed\n");
                exit(0);
            }
            close(fd);
            if ((st.type != T_DIR)){
                printf("%s [error opening dir]\n", path);
            }
            else{
                mp0(path, key);
                glo_dir_num--;
            }
        }

        close(pipe1_fd[0]);
        close(pipe2_fd[0]);
        write(pipe1_fd[1], &glo_dir_num, sizeof(glo_dir_num));
        write(pipe2_fd[1], &glo_file_num, sizeof(glo_file_num));
        
        exit(0);
    }
    else if(PID > 0){
        wait(0);
        close(pipe1_fd[1]);
        close(pipe2_fd[1]);
        read(pipe1_fd[0], &dir_num, sizeof(dir_num));
        read(pipe2_fd[0], &file_num, sizeof(file_num));
        printf("\n");
        printf("%d directories, %d files\n", dir_num, file_num);
    }

    
    exit(0);
}