#include "fifo.h"

#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "defs.h"
#include "proc.h"

void q_init(queue_t *q){
	panic("Not implemented yet\n");
}

int q_push(queue_t *q, uint64 e){
	if (q->size >= PG_BUF_SIZE)
		return 0;
	q->bucket[q->size] = e;
	(q->size)++;
	// printf("push pte: %p\n", e);
	return 0;
	// panic("Not implemented yet\n");
}

uint64 q_pop_idx(queue_t *q, int idx){
	if (q->size <= 0)
		panic("nothing to pop\n");
	uint64 poped_pte = q->bucket[idx];
	for (uint i = idx; i < q->size - 1; ++i){
		q->bucket[i] = q->bucket[i+1];
	}
	q->bucket[q->size-1] = 0;
	(q->size)--;
	// printf("pop pte: %p\n", poped_pte);
	return poped_pte;
	// panic("Not implemented yet\n");
}

int q_empty(queue_t *q){
	if (q == 0){
		panic("invalid queue (empty)\n");
		return -1;
	}
	if (q->size == 0)
		return 1;
	else
		return 0;
	// panic("Not implemented yet\n");
}

int q_full(queue_t *q){
	if (q == 0){
		panic("invalid queue (full)\n");
		return -1;
	}
	if (q->size == PG_BUF_SIZE)
		return 1;
	else
		return 0;
	// panic("Not implemented yet\n");
}

int q_clear(queue_t *q){
	panic("Not implemented yet\n");
}

int q_find(queue_t *q, uint64 e){
	int size = q->size;
	for (uint i = 0; i < size; ++i){
		if (q->bucket[i] == e)
			return i;
	}
	// not found, return -1
	return -1;
	// panic("Not implemented yet\n");
}

int q_find_first_unpinned_idx(queue_t *q){
	if (q->size <= 0)
		return -1;

	for (uint i = 0; i < q->size; ++i){
		pte_t *pte = q->bucket[i];
		if ((*pte & PTE_P) == 0)
			return i;
	}
	return -1;
}

int q_count_pinned(queue_t *q){
	int pinned = 0;
	for (uint i = 0; i < q->size; ++i){
		pte_t *pte = q->bucket[i];
		if ((*pte & PTE_P))
			pinned++;
	}
	return pinned;
}