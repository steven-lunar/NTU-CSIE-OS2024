#include "lru.h"

#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "defs.h"
#include "proc.h"

void lru_init(lru_t *lru){
	panic("not implemented yet\n");
}

int lru_push(lru_t *lru, uint64 e){
	if (lru->size >= PG_BUF_SIZE)
		return 0;
	lru->bucket[lru->size] = e;
	(lru->size)++;
	// printf("push pte: %p\n", e);
	return 0;
	// panic("not implemented yet\n");
}

uint64 lru_pop(lru_t *lru, int idx){
	if (lru->size <= 0)
		return 0;
	uint64 poped_pte = lru->bucket[idx];
	for (uint i = idx; i < lru->size - 1; ++i){
		lru->bucket[i] = lru->bucket[i+1];
	}
	lru->bucket[lru->size-1] = 0;
	(lru->size)--;
	
	// printf("pop pte: %p\n", poped_pte);
	return poped_pte;
	// panic("not implemented yet\n");
}

int lru_empty(lru_t *lru){
	if (lru == 0){
		panic("invalid lru (empty)\n");
	}

	if (lru->size == 0)
		return 1;
	else if (lru->size > 0)
		return 0;
	else if (lru->size < 0)
		panic("negative size of queue\n");
		
	// panic("not implemented yet\n");
}

int lru_full(lru_t *lru){
	if (lru == 0){
		panic("invalid lru (full)\n");
		return -1;
	}
	if (lru->size == PG_BUF_SIZE)
		return 1;
	else
		return 0;
	// panic("not implemented yet\n");
}

int lru_clear(lru_t *lru){
	panic("not implemented yet\n");
}

int lru_find(lru_t *lru, uint64 e){
	int size = lru->size;
	for (uint i = 0; i < size; ++i){
		if (lru->bucket[i] == e)
			return i;
	}
	// not found, return -1
	return -1;
	// panic("Not implemented yet\n");
	// panic("not implemented yet\n");
}

int lru_find_first_unpinned_idx(lru_t *lru, uint64 e){
	if (lru->size <= 0)
		return -1;

	for (uint i = 0; i < lru->size; ++i){
		pte_t *pte = lru->bucket[i];
		if ((*pte & PTE_P) == 0)
			return i;
	}
	return -1;
}

int lru_count_pinned(lru_t *lru){
	int pinned = 0;
	for (uint i = 0; i < lru->size; ++i){
		pte_t *pte = lru->bucket[i];
		if ((*pte & PTE_P))
			pinned++;
	}
	return pinned;
}