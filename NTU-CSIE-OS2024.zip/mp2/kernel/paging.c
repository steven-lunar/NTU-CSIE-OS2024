#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "defs.h"
#include "proc.h"

/* NTU OS 2024 */
/* Allocate eight consecutive disk blocks. */
/* Save the content of the physical page in the pte */
/* to the disk blocks and save the block-id into the */
/* pte. */
char *swap_page_from_pte(pte_t *pte) {
  char *pa = (char*) PTE2PA(*pte);
  uint dp = balloc_page(ROOTDEV);

  write_page_to_disk(ROOTDEV, pa, dp); // write this page to disk
  *pte = (BLOCKNO2PTE(dp) | PTE_FLAGS(*pte) | PTE_S) & ~PTE_V;

  return pa;
}

/* NTU OS 2024 */
/* Page fault handler */
int handle_pgfault() {
  /* Find the address that caused the fault */
  /* uint64 va = r_stval(); */
  
  /* TODO */
  struct proc* p = myproc();
  uint64 va = r_stval();
  va = PGROUNDDOWN(va);
  pte_t *pte = walk(p->pagetable, va, 0);
  uint64 pa = (uint64) kalloc();
  memset(pa, 0, PGSIZE);
  if (*pte & PTE_S){
    begin_op();
    uint block_num = PTE2BLOCKNO(*pte);
    read_page_from_disk(ROOTDEV, pa, block_num);
    bfree_page(ROOTDEV, block_num);
    end_op();
  }
  int mapping_flag = 0;
  if (*pte & PTE_D)
    mapping_flag = mappages(p->pagetable, va, PGSIZE, pa, (PTE_U | PTE_R | PTE_W | PTE_X | PTE_D));
  else
    mapping_flag = mappages(p->pagetable, va, PGSIZE, pa, (PTE_U | PTE_R | PTE_W | PTE_X));
  if (mapping_flag != 0)
    panic("handle page fault mapping fail\n");

  //setting bits
  // *pte |= PTE_U;
  // *pte |= PTE_R;
  // *pte |= PTE_W;
  // *pte |= PTE_X;
  // panic("not implemented yet\n");
}
