#include "kernel/types.h"
#include "user/setjmp.h"
#include "user/threads.h"
#include "user/user.h"
#define NULL 0

static struct thread* current_thread = NULL;
static int id = 1;
// static jmp_buf env_st;
// static jmp_buf env_tmp;
static jmp_buf start_buf;

struct thread *thread_create(void (*f)(void *), void *arg){
    struct thread *t = (struct thread*) malloc(sizeof(struct thread));
    unsigned long new_stack_p;
    unsigned long new_stack;
    new_stack = (unsigned long) malloc(sizeof(unsigned long)*0x100);
    new_stack_p = new_stack +0x100*8-0x2*8;
    t->fp = f;
    t->arg = arg;
    t->ID  = id;
    t->buf_set = 0;
    t->stack = (void*) new_stack;
    t->stack_p = (void*) new_stack_p;
    id++;

    //added for part 2 
    t->mod_stack_p = (void *) new_stack_p;
    t->curr_task = NULL;
    return t;
}
void thread_add_runqueue(struct thread *t){
    if(current_thread == NULL){
        // TODO
        current_thread = t;
        current_thread->previous = t;
        current_thread->next = t;
    }
    else{
        // TODO
        t->previous = current_thread->previous;
        t->next = current_thread;
        current_thread->previous->next = t;
        current_thread->previous = t;
    }
    return;
}
void thread_yield(void){
    // TODO
    // printf("current thread %d sp: %d\n", current_thread->ID, current_thread->env->sp);
    
    // printf("current thread %d sp: %d\n", current_thread->ID, current_thread->env->sp);
    // int jmp_val_task = 0;
    // if ((current_thread->curr_task != NULL) && (current_thread->curr_task->buf_set != 0)){
    //     jmp_val_task = setjmp(current_thread->curr_task->env_f);
    // }

    // To determine who calls this yield function, thread or task?
    int jmp_val_task = 0;
    int jmp_val_thread = 0;
    if (current_thread->curr_task != NULL){
        // task call
        // printf("saving task sp before setjmp(yield): %d\n", current_thread->curr_task->env_f->sp);
        jmp_val_task = setjmp(current_thread->curr_task->env_f);
        // if (jmp_val_task == 0)
        //     printf("saving task sp after setjmp(yield): %d\n", current_thread->curr_task->env_f->sp);
        // if (jmp_val_task == 1)
        //     printf("restoring task sp after longjmp to (yield): %d\n", current_thread->curr_task->env_f->sp);
    }
    else{
        // if (jmp_val_task)
        // printf("longjmp by task\n");
        // printf("saving thread sp before setjmp(yield): %d\n", current_thread->env->sp);
        jmp_val_thread = setjmp(current_thread->env);
        // if (jmp_val_thread == 0)
            // printf("saving thread sp after setjmp(yield): %d\n", current_thread->env->sp);
        // if (jmp_val_thread == 1)
            // printf("saving thread sp after longjmp to (yield): %d\n", current_thread->env->sp);
    }
    // thread call
    
    
    // printf("%d\n", current_thread->env->sp);
    // printf("jmp_val_task: %d\n", jmp_val_task);
    // printf("jmp_val_thread: %d\n", jmp_val_thread);

    if (current_thread->top_task != NULL){
        // update the current task, for the next round (assigned by self)
        current_thread->curr_task = current_thread->top_task;
        if (jmp_val_task == 0){
            schedule();
            // printf("%d yield (with task), now processing thread %d\n", current_thread->previous->ID, current_thread->ID);
            dispatch();
            while(current_thread->curr_task != NULL){
                // printf("thread %d after returning, run previous task\n", current_thread->ID);
                dispatch();
            }
            // longjmp(current_thread->curr_task->env_f, 1);
        }
        // if (jmp_val_task && (current_thread->curr_task != NULL))
        //     dispatch();
        
    }
    else{
        if (jmp_val_thread == 0){
            schedule();
            // printf("%d yield, now processing thread %d\n", current_thread->previous->ID, current_thread->ID);
            dispatch();
        }
        else{
            // printf("return\n");
            return;
        }
    }
    
    
}
void dispatch(void){
    // TODO
    // printf("thread %d dispatch\n", current_thread->ID);
    if (current_thread->curr_task != current_thread->top_task)
        current_thread->curr_task = current_thread->top_task; //task assigned by others, update

    if (current_thread->curr_task != NULL){
        // have task, do task
        while (current_thread->curr_task != NULL){
        if (current_thread->curr_task->buf_set == 0){
            // initialize the task sp
            int jmp_val_task = setjmp(current_thread->curr_task->env_f);
            if (jmp_val_task == 0){
                // printf("Before task initialization thread %d:\n", current_thread->ID);
                // printf("thread task stack pointer: %d, jmp_buf->sp: %d\n", current_thread->curr_task->task_stack_p, current_thread->curr_task->env_f->sp);
                // printf("thread buf_set: %d\n", current_thread->curr_task->buf_set);
                current_thread->curr_task->buf_set = 1;
                current_thread->curr_task->env_f->sp = (long unsigned int) current_thread->curr_task->task_stack_p;
                longjmp(current_thread->curr_task->env_f, 1);
            }
            else{
                // printf("After initialization thread %d:\n", current_thread->ID);
                // printf("thread stack pointer: %d, jmp_buf->sp: %d\n", current_thread->curr_task->task_stack_p, current_thread->curr_task->env_f->sp);
                // printf("thread buf_set: %d\n", current_thread->curr_task->buf_set);
                current_thread->curr_task->fp(current_thread->curr_task->arg);
                // printf("task on thread %d returns\n", current_thread->ID);

                // remove task
                // struct task *tk = current_thread->curr_task;
                current_thread->top_task = current_thread->top_task->prev_task;
                current_thread->curr_task = current_thread->top_task;
                if (!current_thread->curr_task){
                    // printf("empty task\n");
                    if (current_thread->buf_set == 1){
                        // printf("jump to original thread\n");
                        // printf("original thread sp: %d\n", current_thread->env->sp);
                        longjmp(current_thread->env, 0);
                    }
                }
                // free(tk);
                //TODO: return task function to run next task on the same thread
                // if (current_thread->curr_task != NULL){
                //     longjmp(current_thread->curr_task->env_f, 1);
                // }
                // if (current_thread->curr_task == NULL)
                //     longjmp(current_thread->env, 1);
            }
        }
        else{
            longjmp(current_thread->curr_task->env_f, 1);
        }
        }
        
    }
    // else{
        // no task, just initialized the thread
        if (current_thread->buf_set == 0){
            int jmp_val = setjmp(current_thread->env);
            if (jmp_val == 0){
                // printf("Before initialization thread %d:\n", current_thread->ID);
                // printf("thread stack pointer: %d, jmp_buf->sp: %d\n", current_thread->stack_p, current_thread->env->sp);
                // printf("thread buf_set: %d\n", current_thread->buf_set);
                current_thread->buf_set = 1;
                current_thread->env->sp = (long unsigned int) current_thread->stack_p;
                longjmp(current_thread->env, 1);
            }
            else{
                // printf("After initialization thread %d:\n", current_thread->ID);
                // printf("thread stack pointer: %d, jmp_buf->sp: %d\n", current_thread->stack_p, current_thread->env->sp);
                // printf("thread buf_set: %d\n", current_thread->buf_set);
                current_thread->fp(current_thread->arg);
                // printf("thread %d returns\n", current_thread->ID);
                thread_exit();
            }
        }
        else{
            // printf("longjmp to thread %d\n", current_thread->ID);
            longjmp(current_thread->env, 1);
        }
    // }
    
}
void schedule(void){
    // TODO
    current_thread = current_thread->next;
    return;
}
void thread_exit(void){

    if(current_thread->next != current_thread){
        // TODO
        struct thread *t = current_thread;
        current_thread->previous->next = current_thread->next;
        current_thread->next->previous = current_thread->previous;
        schedule();
        free(t->stack);
        free(t);
        dispatch();
    }
    else{
        // TODO
        // Hint: No more thread to execute
        current_thread = NULL;
        longjmp(start_buf, 1);
        return;
    }
    
}
void thread_start_threading(void){
    // TODO
    int jmp_val = setjmp(start_buf);
    if (jmp_val == 0)
        dispatch();
    return;
}

// part 2
void thread_assign_task(struct thread *t, void (*f)(void *), void *arg){
    // TODO
    struct task *tk = task_create(f, arg);
    // t->mod_stack_p = t->mod_stack_p - 0x2*8;
    // tk->stack_pos = t->mod_stack_p;

    if (t->top_task == NULL){
        t->top_task = tk;
    }
    else{
        tk->prev_task = t->top_task;
        t->top_task->next_task = tk;
        t->top_task = tk;
    } 
}

struct task *task_create(void (*f)(void *), void *arg){
    struct task *t = (struct task*) malloc(sizeof(struct task));
    t->fp = f;
    t->arg = arg;
    t->buf_set = 0;

    unsigned long new_stack_p;
    unsigned long new_stack;
    new_stack = (unsigned long) malloc(sizeof(unsigned long)*0x100);
    new_stack_p = new_stack +0x100*8-0x2*8;
    t->task_stack = (void*) new_stack;
    t->task_stack_p = (void*) new_stack_p;

    t->prev_task = NULL;
    t->next_task = NULL;
    return t; 
}